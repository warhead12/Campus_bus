Frontend and Backend code for Bus Booking System, Register and Login only by entering @iiita.ac.in domain.

Before Login Page
![image](https://github.com/user-attachments/assets/4848bc98-4f21-4033-9404-7bf3247e49d5)

![Screenshot 2024-11-21 121508](https://github.com/user-attachments/assets/15f9a309-7be0-4b36-b0b0-1a9d135d7e90)

Seat Booking
![Screenshot 2024-11-21 121605](https://github.com/user-attachments/assets/59de7882-7cdc-4787-8e17-51b538dc93fc)
![Screenshot 2024-11-21 121652](https://github.com/user-attachments/assets/9166ad61-b04c-4a02-ba43-a6ec59ceddfb)

Ticket
![Screenshot 2024-11-21 121913](https://github.com/user-attachments/assets/a86c1993-0240-490f-8614-c34566c724f5)


Live Location
![Screenshot 2024-11-21 121725](https://github.com/user-attachments/assets/6665b045-a770-4826-8e64-19a50d0027d1)

Booked Tickets
![Screenshot 2024-11-21 122055](https://github.com/user-attachments/assets/19893314-39cb-4bbe-9092-a9bbf6721f2e)

Query And FeedBack
![Screenshot 2024-11-21 122152](https://github.com/user-attachments/assets/bdeb55a8-1b72-4b64-a3c7-1894c6b4e99e)











